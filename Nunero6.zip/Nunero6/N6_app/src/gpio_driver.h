/*
 * gpio_driver.h
 *
 *  Created on: Nov 3, 2022
 *      Author: LAMAS38
 */

#ifndef SRC_GPIO_DRIVER_H_
#define SRC_GPIO_DRIVER_H_

#define	GPIO_BASE	(uint32_t)	0x41200000
#define	SW_BASE			GPIO_BASE	+	0x1
typedef	struct	gpio_struct	{
volatile		uint32_t	DATA;
volatile		uint32_t	MODE;
}	gpio_struct;
gpio_struct*	SW		=		(gpio_struct*)	SW_BASE;



#endif /* SRC_GPIO_DRIVER_H_ */
